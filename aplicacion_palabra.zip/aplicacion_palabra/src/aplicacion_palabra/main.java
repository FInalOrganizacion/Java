package aplicacion_palabra;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class main {
	
	public static void  main(String[] args){
	
				aplicacion nuevo = new aplicacion();
				nuevo.setCadena(JOptionPane.showInputDialog("INGRESE UNA PALABRA"));
				nuevo.show_inf();


		        /*for(int c=0; c<frase.length();c++)
		        {
		            for(int x=0;x<vocales.length;x++){
		                if(frase.charAt(c)== vocales[x])
		                    aux+=1;
		           }
		        }*/
		      
		    }
		    
		    
		}
